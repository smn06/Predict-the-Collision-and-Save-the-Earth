
# importing sys
import sys
 
# adding Folder_2/subfolder to the system path
sys.path.insert(0, '/media/smn06/88849B27849B16B2/project/test/Predict the Collision and Save the Earth/src/models')
 
# importing the hello
from __init__ import *
 
main()