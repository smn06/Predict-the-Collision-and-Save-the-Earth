#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 12 12:16:49 2022

@author: mosfak
"""

from predict_collision.my_func import main_fun